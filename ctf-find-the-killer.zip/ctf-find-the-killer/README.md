# 🔎 CTF: The NovaEdge Case — Find the Killer

**Category:** Digital Forensics
**Difficulty:** Beginner / Intro DFIR
**Format:** Jeopardy-style, 4 flags, story-driven

---

## 📖 The Story

Late on the night of **November 14, 2024**, **Arjun Mehta**, CEO and
co-founder of NovaEdge Technologies, was found dead in his 5th-floor
office. He had told colleagues he was staying late to discuss a
"serious accounting issue" with someone before the next morning's
board meeting.

Three people are known to have had access to the building that night:

| Suspect | Role |
|---|---|
| **Neha Kapoor** | Co-founder / CFO |
| **Suresh Yadav** | Night security guard |
| **Priya Sinha** | Ex-employee, terminated two weeks earlier |

You are the digital forensics analyst assigned to the case. The
investigation team has handed you four pieces of digital evidence
recovered from company systems and personal devices. Work through
them, capture the flags, and identify **who killed Arjun Mehta**.

---

## 🎯 Objective

Analyze each file in `evidence/` and recover the hidden flag inside
it. All flags follow the format:

```
FLAG{...}
```

There are **4 flags** total. The last flag names the killer.

---

## 🧰 Evidence Files

| File | What it is |
|---|---|
| `evidence/01_crime_scene_photo.jpg` | A photo auto-synced from a phone backup service |
| `evidence/02_email_dump.txt` | Exported company mail server logs |
| `evidence/03_recovered_fragment.bin` | A corrupted fragment recovered from unallocated disk space |
| `evidence/04_locked_evidence.zip` | A password-protected archive recovered from a cloud backup |

## 🛠️ Suggested Tools

- `exiftool` or Python `piexif` / `Pillow` — image metadata
- A plain text editor / `cat` / `less` — reading raw email headers
- `strings`, `binwalk`, `xxd` — recovering text from binary data
- `unzip` — opening the locked archive **once you find the password**
  (hidden inside earlier evidence — read carefully!)

## 📥 How to Submit

Record your four flags and your final answer (the killer's name) in
this format:

```
Flag 1: FLAG{...}
Flag 2: FLAG{...}
Flag 3: FLAG{...}
Flag 4: FLAG{...}
Killer: <name>
Motive: <one sentence>
```

## 💡 Hints

Progressive hints are available in [`hints.md`](hints.md) if you get
stuck — try to solve each stage without them first!

---

*This is a fictional training scenario. All names, companies, and
events are invented for educational purposes.*
