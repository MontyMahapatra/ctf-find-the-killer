# Hints

Use these one at a time — try each evidence file yourself first.

## Evidence 1 — Photo
<details><summary>Hint 1</summary>
Photos carry more data than what you see. Metadata (EXIF) can store
GPS coordinates, timestamps, device/software info, and even free-text
comment fields.
</details>
<details><summary>Hint 2</summary>
Try `exiftool evidence/01_crime_scene_photo.jpg`. Look closely at the
"User Comment" and "Software" fields.
</details>

## Evidence 2 — Emails
<details><summary>Hint 1</summary>
Never trust the "From" name or the body text alone. Look at the full
raw headers of each message — especially `Received:` and any
`X-` prefixed headers.
</details>
<details><summary>Hint 2</summary>
Compare what Neha *says* in her email body to what the mail server's
own headers say about where the message actually came from.
</details>

## Evidence 3 — Recovered Fragment
<details><summary>Hint 1</summary>
This file is not meant to be opened as an image or document — it's
raw carved data. What tool pulls readable text out of binary noise?
</details>
<details><summary>Hint 2</summary>
Try `strings evidence/03_recovered_fragment.bin` or open it in a hex
viewer (`xxd`). Read the recovered lines carefully — they tell you
who was *not* the killer.
</details>

## Evidence 4 — Locked Archive
<details><summary>Hint 1</summary>
The password isn't brute-forced — it's hiding in plain sight in
evidence you've already examined.
</details>
<details><summary>Hint 2</summary>
Combine the exact date and time you found in Evidence 1's metadata.
Format: `DDMMYYYY_HHMM` (24-hour time, no colon).
</details>
